
<?php $__env->startSection('content'); ?>


<!--main contents start-->
<main class="main-content">
  <div class="page-title"></div>

  <div class="container-fluid">

    <!-- state start-->
    <div class="row">
      <div class=" col-sm-12">
        <div class="card card-shadow mb-4">
          <div class="card-header">
            <div class="row">
              <div class="col-lg-8 col-8">
                <div class="card-title mt-2">
                  Manage Sub Category
                </div>
              </div>

              <div class="col-lg-4 col-4">
                <a href="<?php echo e(url('subcategory')); ?>"  class="btn btn-primary text-white btn-sm float-right " style=" border-radius: 0px;">Sub Category Add</a>
              </div>
            </div>
          </div>
          <div class="card-body" style="overflow-x:auto;">
            <table id="example" class="table table-bordered table-striped text-center" cellspacing="0">
              <thead>
                <tr>
                  <th>Sl.</th>
                  <th>Show Sl.</th>
                  <th>Item Name</th>
                  <th>Category Name</th>
                  <th>Sub Category Name</th>
                  <th>Status</th>
                  <th>Picture</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>

                <?php
                $i=1;
                ?>

                <?php if(isset($data)): ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viewdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                  <td><?php echo e($i++); ?></td>
                  <td><?php echo e($viewdata->sl); ?></td>
                  <td><?php echo e($viewdata->item_name); ?></td>
                  <td><?php echo e($viewdata->category_name); ?></td>
                  <td><?php echo e($viewdata->subcategory_name); ?></td>
                  <td>
                    <?php if($viewdata->status == 1): ?>
                    <a href="<?php echo e(url('inactivesubcategory/'.$viewdata->id)); ?>" class="btn btn-success btn-sm">Active</a>
                    <?php else: ?>
                    <a href="<?php echo e(url('activesubcategory/'.$viewdata->id)); ?>" class="btn btn-danger btn-sm">Inactive</a>
                    <?php endif; ?>

                  </td>
                  <td>
                    <?php if(isset($viewdata->image)): ?>
                    <img src="<?php echo e(url($viewdata->image)); ?>" class="zoom" style="max-height: 50px;">
                    <?php else: ?>
                    <img src="<?php echo e(url('public/image/subcategoryimage')); ?>/1.jpg" class="zoom" style="max-height:50px;">
                    <?php endif; ?>
                  </td>
                  <td>
                    <span>
                      <a href="<?php echo e(url('deletesubcategory/'.$viewdata->id)); ?>" onclick="return confirm('Are You sure ?')" class="btn btn-danger btn-sm" style="padding-left: 10px; padding-right: 10px; border-radius: 0px;"><i class="ti-trash"></i></a>

                      <a href="<?php echo e(url('subcategoryedit/'.$viewdata->id)); ?>"  class="btn btn-info btn-sm" style="padding-left: 10px; padding-right: 10px; border-radius: 0px;"><i class="ti-pencil-alt
                        "></i></a>
                      </span>
                    </td>
                  </tr>                 

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>

                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>


      <!-- state end-->

    </div>

  </main>
  <!--main contents end-->



  <?php $__env->stopSection(); ?>


  
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoppingstore\resources\views/admin/category/managesubcategory.blade.php ENDPATH**/ ?>