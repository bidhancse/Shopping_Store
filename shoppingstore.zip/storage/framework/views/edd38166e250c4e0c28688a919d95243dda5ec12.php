
<?php $__env->startSection('content'); ?>


<div class="col-sm-12 col-12 mt-4 mb-4" style="background-color: #fff;">
	<div class="container-fluid">
		<div class="row">

			<div class="col-lg-2 col-md-12 col-sm-12 col-12 d-none d-sm-block p-0">

				<a href="#" class="list-group-item active text-uppercase" style="border: none; border-radius: 0px; background: black;">
					Brand
				</a>

				
			</div>


			<input type="hidden" name="item_id"  id="item_id" value="57">
			<div class="col-lg-10 col-md-12 col-sm-12 col-12">

				<div>
					

					<ul class="uk-breadcrumb" style="margin-top: -7px;">
						<li style="color: #666;">
							<a href="<?php echo e('/eshop'); ?>" style="color: #666;" class="text-uppercase">Home</a>
							<span class="text-uppercase"> &nbsp;&nbsp; / &nbsp;&nbsp; <?php echo e($SubCategoryName->item_name); ?></span>
							<span class="text-uppercase"> &nbsp;&nbsp; / &nbsp;&nbsp; <?php echo e($SubCategoryName->category_name); ?></span>
							<span class="text-uppercase"> &nbsp;&nbsp; / &nbsp;&nbsp; <?php echo e($SubCategoryName->subcategory_name); ?></span>
						</li>
					</ul>

				</div>

				<div class="col-sm-12 col-12 p-0" style="margin-top: 4px;">
					<div class="row" id="showproduct-130">

						<?php if(isset($SubCategoryProduct)): ?>
						<?php $__currentLoopData = $SubCategoryProduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $SubCategoryProductshow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<div class="col-lg-3 cl-md-4 col-sm-6 col-6 mt-4" >
							<div class="homeproducts border">
								
								<?php
								$dis_percentig = $SubCategoryProductshow->discount_price / $SubCategoryProductshow->sale_price*100;
								?>

								<?php if(isset($SubCategoryProductshow->discount_price)): ?>
								<span class="mark" style="margin-left: 0px; padding: 3px 10px 3px 10px; background-color: #00c431; color: #fff;"><?php echo e(ceil($dis_percentig)); ?> % OFF</span>
								<?php else: ?>
								<span class="mark1" style="margin-left: -18px;"></span>
								<?php endif; ?>
								
								<center>
									<a href="<?php echo e(url('product/'.$SubCategoryProductshow->id)); ?>"><img src="<?php echo e(url($SubCategoryProductshow->image)); ?>" class="img-fluid" style="z-index:1; "></a>
								</center>
								<div>
									<a href=""><center>
										<?php
										$content = substr($SubCategoryProductshow->product_name,0,20);
										$sale_price = $SubCategoryProductshow->sale_price;
										$dis_price = $SubCategoryProductshow->discount_price;
										$present_price = $sale_price-$dis_price;
										?>

										<?php echo $content; ?><br>

										<span style="font-size: 15px;">
											<?php if(isset($dis_price)): ?>
											<del><?php echo e($SubCategoryProductshow->sale_price); ?></del> &nbsp;&nbsp;
											<?php endif; ?>

											Tk <?php echo e($present_price); ?>.00
										</span>
									</a>
								</div>
							</div>
						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>

					</div>
				</div>

				<div class="row">
					<div class="col-sm-12 col-12 mt-5" >
						<nav>
							<ul class="pagination"style="color: black;">
								<?php echo e($SubCategoryProduct->links()); ?>

							</ul>
						</nav>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoppingstore\resources\views/frontend/subcategory/subcategory.blade.php ENDPATH**/ ?>