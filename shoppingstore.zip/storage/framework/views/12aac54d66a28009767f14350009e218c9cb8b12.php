
<?php $__env->startSection('content'); ?>



<div class="col-sm-12 col-12 mt-4 pb-5">
	<div class="container border p-3">
		<div>
			<ul class="uk-breadcrumb">
				<li><a href="<?php echo e('/shoppingstore'); ?>">Home</a> &nbsp; / &nbsp; <span>FAQ</span></li>

			</ul>
		</div>

		<span class="detailspage">
			<div id="accordion" style="margin-top: 20px;">


				<?php if(isset($FAQ)): ?>
				<?php $__currentLoopData = $FAQ; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $FAQshow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



				<div class="card p-4">
					<div class="card-header" id="headingOne2">
						<h5 class="mb-0">
							<button class="btn btn-link d-flex align-items-center justify-content-between collapsed" data-toggle="collapse" data-target="#<?php echo e($FAQshow->id); ?>" aria-expanded="false" aria-controls="<?php echo e($FAQshow->id); ?>" style="width:100%; text-decoration: none; color: black;">
								<?php echo e($FAQshow->question); ?>

								<span class="fa-stack fa-sm">
									<i class="fa fa-plus" style="color: #00c431;"></i>
								</span>
							</button>
						</h5>
					</div>

					<div id="<?php echo e($FAQshow->id); ?>" class="collapse" aria-labelledby="headingOne2" data-parent="#accordion">
						<div class="card-body">
							<?php echo $FAQshow->details; ?>

						</div>
					</div>
				</div>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php endif; ?>

			</div>
		</span>
		

		
	</div>
</div>






<?php $__env->stopSection(); ?>



<?php echo $__env->make('frontend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoppingstore\resources\views/frontend/websitesetting/faq.blade.php ENDPATH**/ ?>