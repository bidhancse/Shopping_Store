
<?php $__env->startSection('content'); ?>


<!--/ Start Slider Area -->
<div>
    <!--Carousel Wrapper-->
    <div id="carousel-example-2" class="carousel slide carousel-fade" data-ride="carousel" style="padding:0px; margin:0px;">
        <!--Indicators-->
        <ol class="carousel-indicators">
            <li data-target="#carousel-example-2" data-slide-to="0" class="active" ></li>

            <?php if(isset($slidermore)): ?>
            <?php for($i=1; $i<=count($slidermore); $i++): ?>

            <li data-target="#carousel-example-2" data-slide-to="<?php echo e($i); ?>"></li>

            <?php endfor; ?>
            <?php endif; ?>
            
        </ol>

        <div class="carousel-inner" role="listbox">
            <div class="carousel-item active">
                <div class="view">
                    <img class="d-block w-100" src="<?php echo e(url($slideractive->image)); ?>"
                    alt="First slide">
                    <div class="mask rgba-black-light"></div>
                </div>
                <div class="carousel-caption">
                    
                </div>
            </div>

            <?php if(isset($slidermore)): ?>
            <?php $__currentLoopData = $slidermore; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sliderview): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="carousel-item">
                <div class="view">
                    <img class="d-block w-100"  src="<?php echo e(url($sliderview->image)); ?>"
                    alt="Second slide">
                    <div class="mask rgba-black-strong"></div>
                </div>
                <div class="carousel-caption">
                
            </div>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

    </div>
</div>
</div>
<!--/ End Slider Area -->


<!--/ Start Categories Area -->

<div class="col-md-12 pt-5" style="background-color: #fff;">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="section-title">
                    <h2><span  style="font-size: 23px;">Shop By Categories </span><br>
                        <span style="font-size: 14px; color: gray; font-family: Calibri; margin-top: -5px;">Get Your Product from Category</span>
                    </h2>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="col-sm-12 col-12 pb-5" style="background-color: #fff;">
    <div class="container-fluid" style="padding-top:8px;">
        <div class="col-sm-12 col-12 p-0">
            <div class="row" id="showproduct-130">

                <?php if(isset($item)): ?>
                <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemshow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php 
                $ProductCount = DB::table('productinformation')->where('item_id',$itemshow->id)->get();
                ?>

                <div class="p-2 col-lg-2 col-md-3 col-sm-4 col-6" >
                    <div class="homeproducts">
                        <center>
                            <a href="<?php echo e(url('item/'.$itemshow->id)); ?>">

                                <?php if(isset($itemshow->image)): ?>
                                <img src="<?php echo e(url($itemshow->image)); ?>"
                                class="img-fluid" style="z-index:1; max-height: 120px;">
                                <?php endif; ?>

                            </a>
                        </center>

                        <div class="text-center">
                            <a href="<?php echo e(url('item/'.$itemshow->id)); ?>">
                                <?php echo e($itemshow->item_name); ?><br>
                                <?php echo e(count($ProductCount)); ?> Product's
                            </a>
                        </div>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </div>
        </div>
    </div>
</div>
</div>
</div>
</div>
</div>
<!--/ End Categories Area -->


<!--/ Start Product Area -->

<?php if(isset($category)): ?>
<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryshow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php
$products = DB::table('productinformation')->where('category_id',$categoryshow->id)->first();
?>

<?php if($products): ?>

<div class="col-md-12 pt-5" style="background-color: #f2fff5;">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12" style="margin-top: -35px;">
                <div class="section-title">
                    <h2><?php echo e($categoryshow->category_name); ?></h2>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="col-sm-12 col-12 pb-5" style="background-color: #f2fff5;">
    <div class="container-fluid" style="margin-top: -27px;">
        <div class="col-sm-12 col-12 p-0">
            <div class="row" id="showproduct-130">

                <?php
                $product = DB::table('productinformation')->where('category_id',$categoryshow->id)->inRandomOrder()->limit(6)->get();
                ?>

                <?php if(isset($product)): ?>
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Productshow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($categoryshow->id == $Productshow->category_id): ?>

                <div class="col-lg-2 cl-md-4 col-sm-6 col-6 mt-4" >
                    <div class="homeproducts">

                        <?php
                        $dis_percentig = $Productshow->discount_price / $Productshow->sale_price*100;
                        ?>

                        <?php if(isset($Productshow->discount_price)): ?>
                        <span class="mark" style="margin-left: 0px; padding: 3px 10px 3px 10px; background-color: #00c431; color: #fff;"><?php echo e(ceil($dis_percentig)); ?> % OFF</span>
                        <?php else: ?>
                        <span class="mark1" style="margin-left: -18px;"></span>
                        <?php endif; ?>
                        <center>
                            <a
                            href="<?php echo e(url('product/'.$Productshow->id)); ?>">

                            <?php if(isset($Productshow->image)): ?>
                            <img src="<?php echo e(url($Productshow->image)); ?>"
                            class="img-fluid" style="z-index:1;">
                            <?php endif; ?>

                        </a>
                    </center>

                    <div class="text-center">
                        <a
                        href="<?php echo e(url('product/'.$Productshow->id)); ?>">
                        <?php
                        $content = substr($Productshow->product_name,0,20);
                        $sale_price = $Productshow->sale_price;
                        $dis_price = $Productshow->discount_price;
                        $present_price = $sale_price-$dis_price;
                        ?>

                        <?php echo $content; ?><br>

                        <span style="font-size: 15px;">
                            <?php if(isset($dis_price)): ?>
                            <del><?php echo e($Productshow->sale_price); ?></del> &nbsp;&nbsp;
                            <?php endif; ?>

                            Tk <?php echo e($present_price); ?>.00
                        </span>
                    </a>
                </div>
            </div>
        </div>

        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

    </div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>

<?php else: ?>
<?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<!-- End Product Area  -->





<!-- Start Shop Services Area -->
<section class="shop-services section home">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6 col-12">
                <!-- Start Single Service -->
                <div class="single-service">
                    <i class="ti-rocket"></i>
                    <h4>Free Shipping</h4>
                    <p>Orders over 2000 Tk</p>
                </div>
                <!-- End Single Service -->
            </div>
            <div class="col-lg-3 col-md-6 col-12">
                <!-- Start Single Service -->
                <div class="single-service">
                    <i class="ti-reload"></i>
                    <h4>Free Return</h4>
                    <p>Within 30 days returns</p>
                </div>
                <!-- End Single Service -->
            </div>
            <div class="col-lg-3 col-md-6 col-12">
                <!-- Start Single Service -->
                <div class="single-service">
                    <i class="ti-lock"></i>
                    <h4>Sucure Payment</h4>
                    <p>100% secure payment</p>
                </div>
                <!-- End Single Service -->
            </div>
            <div class="col-lg-3 col-md-6 col-12">
                <!-- Start Single Service -->
                <div class="single-service">
                    <i class="ti-tag"></i>
                    <h4>Best price</h4>
                    <p>Guaranteed price</p>
                </div>
                <!-- End Single Service -->
            </div>
        </div>
    </div>
</section>
<!-- End Shop Services Area -->



<?php $__env->stopSection(); ?>




<?php echo $__env->make('frontend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shopping\resources\views/frontend/home.blade.php ENDPATH**/ ?>