
<?php $__env->startSection('content'); ?>


<!--main contents start-->
<main class="main-content">
  <div class="page-title">

  </div>


  <div class="container-fluid">

    <div class="row">
      <div class="col-lg-12">
        <div class="card card-shadow mb-4">
          <div class="card-header">
            <div class="row">
              <div class="col-lg-8 col-8">
                <div class="card-title mt-2">
                  Create Subcategory
                </div>
              </div>

              <div class="col-lg-4 col-4">
                <a href="<?php echo e(url('managesubcategory')); ?>"  class="btn btn-success text-white btn-sm float-right " style=" border-radius: 0px;">View Category</a>
              </div>

            </div>

          </div>
          <div class="card-body">
            <form method="POST" enctype="multipart/form-data" action="<?php echo e(url('subcategoryupdate/'.$data->id)); ?>">
              <?php echo csrf_field(); ?>

              <div class="row">
                <div class="col-lg-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Serial No</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Serial No" name="sl" style="border-radius: 0px;" required="" readonly  value="<?php echo e($data->sl); ?>">
                  </div>
                </div>

                <div class="col-lg-6">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Item Name</label>
                    <select class="form-control" name="item_id" required="" style="border-radius: 0px;">
                     <?php if(isset($item)): ?>
                     <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viewdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                     <option value="<?php echo e($viewdata->id); ?>" <?php if($data->item_id == $viewdata->id){ echo "selected";} ?>><?php echo e($viewdata->item_name); ?></option>

                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php endif; ?>
                   </select>
                 </div>
               </div>
             </div>

             <div class="row">
              <div class="col-lg-6">
                <div class="form-group">
                  <label for="exampleInputEmail1">Category Name</label> <label class="text-danger">(Must be English **)</label>
                  <select class="form-control" name="category_id" style="border-radius: 0px;">
                   <?php if(isset($category)): ?>
                   <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viewdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                   <option value="<?php echo e($viewdata->id); ?>" <?php if($data->category_id == $viewdata->id ){ echo "selected";} ?>><?php echo e($viewdata->category_name); ?></option>

                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   <?php endif; ?>
                 </select>
               </div>
             </div>

             <div class="col-lg-6">
               <div class="form-group">
                <label for="exampleInputEmail1">Subcategory Name</label>
                <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter Subcategory Name" name="subcategory_name" style="border-radius: 0px;" required="" value="<?php echo e($data->subcategory_name); ?>">
              </div>
            </div>
          </div>

          <div class="row">
           <div class="col-lg-6">
            <div class="form-group">
              <label for="exampleInputEmail1">Status</label>
              <select class="form-control" name="status" required="">
                <option value="<?php echo e($data->status); ?>"><?php if($data->status == 1): ?>Active <?php else: ?> Inactive <?php endif; ?></option>
                <?php if($data->status == 1): ?>
                <option value="0">Inactive</option>
                <?php else: ?>
                <option value="1">Active</option>
                <?php endif; ?>
              </select>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="form-group">
              <label for="exampleInputEmail1">Picture</label>
              <input type="file" class="form-control" style="border-radius: 0px;" id="imgInp" name="image">
              <?php if(isset($data->image)): ?>
              <img id="blah" src="<?php echo e(url($data->image)); ?>" style="max-height: 50px;">
              <?php else: ?>
              <img id="blah" src="<?php echo e(url('public/subcategoryimage')); ?>/1.png" style="max-height:50px;">
              <?php endif; ?>
              <input type="hidden" name="old_image" value="<?php echo e($data->image); ?>">
            </div>
          </div>
        </div>


        <div class="form-group row">
          <div class="col-sm-9 mt-2">
            <button type="submit" class="btn btn-info btn-sm" style=" border-radius: 0px;">Create Category</button>
            <button type="reset" class="btn btn-warning btn-sm" style=" border-radius: 0px;">Refresh</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
</div>

</div>

</main>
<!--main contents end-->


<script type="text/javascript">
  $(document).ready(function() {
    $('select[name="item_id"]').on('change', function(){
      var item_id = $(this).val();
      if(item_id) {
        $.ajax({
          url: "<?php echo e(url('/categoryget/')); ?>/"+item_id,
          type:"GET",
          dataType:"json",
          success:function(data) {
            var d =$('select[name="category_id"]').empty();
            $.each(data, function(key, value){
              $('select[name="category_id"]').append('<option value="'+ value.id +'">' + value.category_name + '</option>');

            });

          },

        });
      } else {
        alert('danger');
      }

    });
  });

</script>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoppingstore\resources\views/admin/category/editsubcategory.blade.php ENDPATH**/ ?>