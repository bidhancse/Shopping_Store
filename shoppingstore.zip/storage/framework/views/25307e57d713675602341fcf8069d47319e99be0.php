
<?php $__env->startSection('content'); ?>


<!--main contents start-->
<main class="main-content">
  <div class="page-title"></div>

  <div class="container-fluid">

    <!-- state start-->
    <div class="row">
      <div class=" col-sm-12">
        <div class="card card-shadow mb-4">
          <div class="card-header">
            <div class="row">
              <div class="col-lg-8 col-8">
                <div class="card-title mt-2">
                  Manage Admin
                </div>
              </div>
              <div class="col-lg-4 col-4">
                <a href="<?php echo e(url('createadmin')); ?>"  class="btn btn-primary text-white btn-sm float-right " style=" border-radius: 0px;">Admin Add</a>
              </div>
            </div>
          </div>
          <div class="card-body" style="overflow-x:auto;">
            <table id="example" class="table table-bordered table-striped " cellspacing="0">
              <thead>
                <tr>
                  <th>Sl.</th>
                  <th>Name</th>
                  <th>E-mail</th>
                  <th>Phone</th>
                  <th>Admin name</th>
                  <th>Address</th>
                  <th>Status</th>
                  <th>Picture</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>



                <?php
                $i=1;
                ?>

                <?php if(isset($data)): ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datashow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                  <td><?php echo e($i++); ?></td>
                  <td><?php echo e($datashow->name); ?></td>
                  <td><?php echo e($datashow->email); ?></td>
                  <td><?php echo e($datashow->phone); ?></td>
                  <td><?php echo e(Auth()->user()->name); ?></td>
                  <td><?php echo e($datashow->address); ?></td>
                  <td>
                    <?php if($datashow->status == 1): ?>
                    <a href="<?php echo e(url('inactiveadmin/'.$datashow->id)); ?>" class="btn btn-success btn-sm">Active</a>
                    <?php else: ?>
                    <a href="<?php echo e(url('activeadmin/'.$datashow->id)); ?>" class="btn btn-danger btn-sm">Inactive</a>
                    <?php endif; ?>

                  </td>
                  <td>
                    <?php if(isset($datashow->image)): ?>
                    <img src="<?php echo e(url($datashow->image)); ?>" class="zoom" style="max-height: 50px;">
                    <?php else: ?>
                    <img src="<?php echo e(url('public/image/userimage')); ?>/1.jpg" class="zoom" style="max-height: 50px;">
                    <?php endif; ?>
                  </td>
                  <td>
                    <span>
                      <a href="<?php echo e(url('admindelete/'.$datashow->id)); ?>" onclick="return confirm('Are You sure ?')" class="btn btn-danger btn-sm" style="padding-left: 10px; padding-right: 10px; border-radius: 0px;"><i class="ti-trash"></i></a>

                      <a href="<?php echo e(url('adminedit/'.$datashow->id)); ?>" class="btn btn-info btn-sm" style="padding-left: 10px; padding-right: 10px; border-radius: 0px;"><i class="ti-pencil-alt
                        "></i></a>
                      </span>
                    </td>
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>

                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>


      <!-- state end-->

    </div>

  </main>
  <!--main contents end-->



  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/admin/user/manageadmin.blade.php ENDPATH**/ ?>