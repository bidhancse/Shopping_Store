
<?php $__env->startSection('content'); ?>



<div class="col-sm-12 col-12 pb-5" style="background-color: #fff;">
	<div class="container-fluid" style="padding-top:8px;">

		<div class="col-sm-12 col-12 p-0">
			<div class="row" id="showproduct-130">



				<?php if(isset($Allproduct)): ?>
				<?php $__currentLoopData = $Allproduct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Productshow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<div class="col-lg-2 cl-md-4 col-sm-6 col-6 mt-4" >

					<div class="homeproducts">

						<?php
						$dis_percentig = $Productshow->discount_price / $Productshow->sale_price*100;
						?>

						<?php if(isset($Productshow->discount_price)): ?>
						<span class="mark" style="margin-left: 0px; padding: 3px 10px 3px 10px; background-color: #00c431; color: #fff;"><?php echo e(ceil($dis_percentig)); ?> % OFF</span>
						<?php else: ?>
						<span class="mark1" style="margin-left: -18px;"></span>
						<?php endif; ?>
						<center>
							<a
							href="<?php echo e(url('product/'.$Productshow->id)); ?>">

							<?php if(isset($Productshow->image)): ?>
							<img src="<?php echo e(url($Productshow->image)); ?>"
							class="img-fluid" style="z-index:1;">
							<?php endif; ?>

						</a>
					</center>

					<div class="text-center">
						<a
						href="<?php echo e(url('product/'.$Productshow->id)); ?>">
						<?php
						$content = substr($Productshow->product_name,0,20);
						$sale_price = $Productshow->sale_price;
						$dis_price = $Productshow->discount_price;
						$present_price = $sale_price-$dis_price;
						?>

						<?php echo $content; ?><br>

						<span style="font-size: 15px;">
							<?php if(isset($dis_price)): ?>
							<del><?php echo e($Productshow->sale_price); ?></del> &nbsp;&nbsp;
							<?php endif; ?>

							Tk <?php echo e($present_price); ?>.00
						</span>
					</a>
				</div>
			</div>
		</div>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>

	</div>
</div>


<div class="row">
	<div class="col-sm-12 col-12 mt-5" >
		<nav>
			<center>
				<ul class="pagination" style="color: black;">
					<?php echo e($Allproduct->links()); ?>

				</ul>
			</center>
		</nav>
	</div>
</div>

</div>
</div>






<?php $__env->stopSection(); ?>



<?php echo $__env->make('frontend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/frontend/product/allproduct.blade.php ENDPATH**/ ?>