
<?php $__env->startSection('content'); ?>



<!--main contents start-->
<main class="main-content" style="overflow: hidden;">
  <div class="page-title">

  </div>


  <div class="container-fluid" style="overflow-x: scroll;">

    <!-- state start-->
    <div class="row">
      <div class=" col-sm-12">
        <div class="card card-shadow mb-4">
          <div class="card-header">
            <div class="row">
              <div class="col-lg-8 col-8">
                <div class="card-title mt-2">
                  Create Product
                </div>
              </div>
              <div class="col-lg-4 col-4">
                <a href="<?php echo e(url('product')); ?>"  class="btn btn-primary text-white btn-sm float-right " style=" border-radius: 0px;">Product Add</a>
              </div>
            </div>
          </div>
          </div>
          <div class="card-body bg-white" style="margin-top: -25px;">
            <table id="example" class="display nowrap table table-bordered table-striped" cellspacing="0" style="width: 100%;">
              <thead>
                <tr>
                  <th>Sl.</th>
                  <th>Product Code</th>
                  <th>Product Name</th>
                  <th>Item Name</th>
                  
                  <th>Brand Name</th>
                  <th>Sale Price</th>
                  <th>Stock Status</th>
                  <th>Status</th>
                  <th>Picture</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>

                <?php
                $i=1;
                ?>

                <?php if(isset($data)): ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $viewdata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                  <td><?php echo e($i++); ?></td>
                  <td><?php echo e($viewdata->product_code); ?></td>
                  <td><?php echo e($viewdata->product_name); ?></td>
                  <td><?php echo e($viewdata->item_name); ?></td>
                  
                  <td><?php echo e($viewdata->brand_name); ?></td>
                  <td><?php echo e($viewdata->sale_price); ?></td>

                  <td>
                    <?php if($viewdata->stock_status == 1): ?>
                    <a href="<?php echo e(url('inactivestockstatus/'.$viewdata->id)); ?>" class="btn btn-outline-success btn-sm" style="border-radius: 0px; padding: 10px;">Stock In</a>
                    <?php else: ?>
                    <a href="<?php echo e(url('activestockstatus/'.$viewdata->id)); ?>" class="btn btn-outline-danger btn-sm" style="border-radius: 0px; padding: 10px;">Stock Out</a>
                    <?php endif; ?>
                  </td>

                  <td>
                    <?php if($viewdata->status == 1): ?>
                    <a href="<?php echo e(url('inactiveproduct/'.$viewdata->id)); ?>" class="btn btn-outline-primary btn-sm" style="border-radius: 0px; padding: 10px;">Active</a>
                    <?php else: ?>
                    <a href="<?php echo e(url('activeproduct/'.$viewdata->id)); ?>" class="btn btn-outline-danger btn-sm" style="border-radius: 0px; padding: 10px;">Inactive</i></a>
                    <?php endif; ?>
                  </td>
                  
                  <td>
                    <?php if(isset($viewdata->image)): ?>
                    <img src="<?php echo e(url($viewdata->image)); ?>" class="zoom" style="max-height: 50px;">
                    <?php else: ?>
                    <img src="<?php echo e(url('public/image/productimage')); ?>/1.jpg" class="zoom" style="max-height:50px;">
                    <?php endif; ?>
                  </td>

                  <td>
                    <span>
                      <a href="<?php echo e(url('deleteproduct/'.$viewdata->id)); ?>" onclick="return confirm('Are You sure ?')" class="btn btn-danger btn-sm" style="padding-left: 10px; padding-right: 10px; border-radius: 0px;"><i class="ti-trash"></i></a>

                      <a href="<?php echo e(url('editproduct/'.$viewdata->id)); ?>" class="btn btn-info btn-sm"  style="padding-left: 10px; padding-right: 10px; border-radius: 0px;"><i class="ti-pencil-alt
                        "></i></a>
                      </span>
                    </td>
                  </tr>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>

                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- state end-->

  </div>

</main>
<!--main contents end-->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shop\resources\views/admin/product/manageproduct.blade.php ENDPATH**/ ?>