
<div class="step active"> 
    <span class="faicon"> <i class="fa fa-check"></i> </span> <span class="text">Order confirmed</span> 
</div>
<div class="step active"> 
    <span class="faicon"> <i class="fa fa-user"></i> </span> <span class="text"> Processing</span> 
</div>
<div class="step active"> 
    <span class="faicon"> <i class="fa fa-truck"></i> </span> <span class="text"> Shipping </span> 
</div>
<div class="step active"> 
    <span class="faicon"> <i class="fa fa-box"></i> </span> <span class="text">Delivered</span> 
</div><?php /**PATH C:\xampp\htdocs\shoppingstore\resources\views/frontend/user/ordertrack/completd.blade.php ENDPATH**/ ?>