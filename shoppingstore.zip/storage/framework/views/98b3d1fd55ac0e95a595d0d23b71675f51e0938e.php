<?php
$setting = DB::table('settinginformation')->first();
$contact = DB::table('contactinformation')->first();
?>




<!DOCTYPE html>
<html lang="zxx">
<head>
   <!-- Meta Tag -->
   <meta charset="utf-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name='copyright' content=''>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   <!-- Title Tag  -->
   <title><?php echo e($setting->title); ?></title>
   <!-- Favicon -->
   <link rel="icon" type="image/png" href="<?php echo e(url($setting->favicon)); ?>">
   <!-- Web Font -->
   <link href="https://fonts.googleapis.com/css?family=Poppins:200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

   <!-- StyleSheet -->
   <!-- UIkit CSS -->
   <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/uikit@3.13.1/dist/css/uikit.min.css" />
   <!-- Bootstrap -->
   <link rel="stylesheet" href="<?php echo e(asset('public/frontend')); ?>/css/bootstrap.css">
   <!-- Magnific Popup -->
   <link rel="stylesheet" href="<?php echo e(asset('public/frontend')); ?>/css/magnific-popup.min.css">
   <!-- Font Awesome -->
   <link rel="stylesheet" href="<?php echo e(asset('public/frontend')); ?>/css/font-awesome.css">
   <!-- Fancybox -->
   <link rel="stylesheet" href="<?php echo e(asset('public/frontend')); ?>/css/jquery.fancybox.min.css">
   <!-- Themify Icons -->
   <link rel="stylesheet" href="<?php echo e(asset('public/frontend')); ?>/css/themify-icons.css">
   <!-- Animate CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('public/frontend')); ?>/css/animate.css">
   <!-- Flex Slider CSS -->
   <link rel="stylesheet" href="<?php echo e(asset('public/frontend')); ?>/css/flex-slider.min.css">
   <!-- Owl Carousel -->
   <link rel="stylesheet" href="<?php echo e(asset('public/frontend')); ?>/css/owl-carousel.css">
   <!-- Slicknav -->
   <link rel="stylesheet" href="<?php echo e(asset('public/frontend')); ?>/css/slicknav.min.css">

   <link rel="stylesheet" href="<?php echo e(asset('public/frontend')); ?>/css/reset.css">
   <link rel="stylesheet" href="<?php echo e(asset('public/frontend')); ?>/css/style.css">
   <link rel="stylesheet" href="<?php echo e(asset('public/frontend')); ?>/css/responsive.css">
   <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
   <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
   <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

   <link rel="stylesheet" href="<?php echo e(asset('public/signin')); ?>/css/style.css">
   <link rel="stylesheet" href="<?php echo e(asset('public/backend')); ?>/assets/css/toast.css">

</head>
<body class="js" style="background-color: #fff !important;">

   <style type="text/css">




</style>





 <!-- Header -->
 <header class="header shop">
  <!-- Topbar -->
  <div class="topbar">
     <div class="container">
        <div class="row">
           <div class="col-lg-5 col-md-12 col-12">
              <!-- Top Left -->
              <div class="top-left">
                 <ul class="list-main">
                    <li><i class="ti-headphone-alt"></i>+880 <?php echo e($setting->phone); ?></li>
                    <li><i class="ti-email"></i> <?php echo e($setting->email); ?></li>
                 </ul>
              </div>
              <!--/ End Top Left -->
           </div>
           <div class="col-lg-7 col-md-12 col-12">
            <!-- Top Right -->
            <div class="right-content">
               <ul class="list-main">
                  <?php if(Auth::check()): ?>
                  <li><a href="<?php echo e(url('userdashboard')); ?>" class="single-icon"><i class="fa fa-user" aria-hidden="true" style="font-size: 16px;"></i> My Profile</a></li>
               </form>

               <?php else: ?>
               <li><i class="ti-user"></i> <a href="<?php echo e(url('usersignup')); ?>" >Sign Up</a></li>
               <li><i class="ti-power-off"></i><a href="<?php echo e(url('usersignin')); ?>">Sign In</a></li>
               <?php endif; ?>

            </ul>
         </div>
         <!-- End Top Right -->
      </div>
   </div>
</div>
</div>
<!-- End Topbar -->
<div class="middle-inner">
   <div class="container">
      <div class="row">
         <div class="col-lg-2 col-md-2 col-12">
            <!-- Logo -->
            <div class="logo">
               <a href="<?php echo e('/shoppingstore'); ?>"><img src="<?php echo e(url($setting->image)); ?>" alt="logo"></a>
            </div>



            <!--/ End Logo -->
            <!-- Search Form -->
            <div class="search-top">
               <div class="top-search"><a href="#0"><i class="ti-search"></i></a></div>
               <!-- Search Form -->
               <div class="search-top">
                  <form class="search-form" method="get" action="<?php echo e(url('searchproduct')); ?>">
                     <?php echo csrf_field(); ?>
                     <input type="search" placeholder="Search here..." name="searchdata">
                     <button value="search" type="submit"><i class="ti-search"></i></button>
                  </form>
               </div>
               <!--/ End Search Form -->
            </div>
            <!--/ End Search Form -->
            <div class="mobile-nav"></div>
         </div>


         <div class="col-lg-8 col-md-7 col-12">
          <div class="search-bar-top">
             <div class="search-bar">
                <form method="get" action="<?php echo e(url('searchproduct')); ?>" style="width: 100% !important;">
                   <?php echo csrf_field(); ?>
                   <input type="search" name="searchdata" placeholder="Search Products Here....." required style="width: 100% !important; outline: 0px;">
                   <button class="btnn" type="submit"><i class="ti-search"></i></button>
                </form>
             </div>
          </div>
       </div>
       <div class="col-lg-2 col-md-3 col-12">
        <div class="right-bar">
           <!-- Cart -->
           <div class="sinlge-bar shopping">
              <a href="#" class="single-icon" uk-toggle="target: #offcanvas-none"><i class="fa fa-shopping-basket"></i> <span class="total-count"><?php echo e(Cart::count()); ?></span></a>
           </div>
        </div>
     </div>
  </div>
</div>
</div>




<div id="offcanvas-flip" id="offcanvas-slide" uk-offcanvas="flip: false; overlay: true;">
   <div class="uk-offcanvas-bar d-block sidemenu" id="mobilemenuoff" style="transition: 0.9s; border:none;">
      <button class="uk-offcanvas-close" type="button" uk-close></button>
      <br>
      <br>
      <p style="margin-left: 35px; color: #00c431;">All Categories</p>
      <ul class="uk-nav-parent-icon p-3" uk-nav duration='800'>


         <?php
         $item=DB::table('iteminformation')->orderBy('id','ASC')->where('status',1)->get();
         $category=DB::table('categoryinformation')->where('status',1)->get();
         $subcategory=DB::table('subcategoryinformation')->where('status',1)->get();
         ?>

         <?php if(isset($item)): ?>
         <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemshow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

         <li class="uk-parent text-dark">
            <a href="<?php echo e(url('item/'.$itemshow->id)); ?>" style="color: #fff;">
               <span uk-icon="icon: chevron-right; ratio: 0.9"></span>&nbsp;&nbsp;<?php echo e($itemshow->item_name); ?>

            </a>
            <ul class="uk-nav-sub">

               <?php if(isset($category)): ?>
               <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryshow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php if($itemshow->id == $categoryshow->item_id): ?>

               <li>
                  <a href="<?php echo e(url('category/'.$categoryshow->id)); ?>" style="color: #ffc107">
                     <?php echo e($categoryshow->category_name); ?>

                  </a>
                  <ul>

                     <?php if(isset($subcategory)): ?>
                     <?php $__currentLoopData = $subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategoryshow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if($categoryshow->id == $subcategoryshow->category_id): ?>

                     <li>
                        <a href="<?php echo e(url('subcategory/'.$subcategoryshow->id)); ?>" style="color: #fff">
                           <?php echo e($subcategoryshow->subcategory_name); ?>

                        </a>
                     </li>

                     <?php endif; ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php endif; ?>

                  </ul>
               </li>

               <?php endif; ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php endif; ?>

            </ul>
         </li>

         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?>

      </ul>
   </div>
</div>
<!----------------End Mobile Menu------------->



<!-- Header Inner -->
<div class="header-inner">
   <div class="container">
      <div class="cat-nav-head">
         <div class="row">
            <div class="col-lg-3">
               <div class="all-category">
                  <h3 class="cat-heading" onmouseover="categoryHideShow()"><i class="fa fa-bars" aria-hidden="true"></i>CATEGORIES</h3>


                  <ul class="main-category opacity">

                     <?php
                     $item=DB::table('iteminformation')->orderBy('id','ASC')->where('status',1)->get();
                     $category=DB::table('categoryinformation')->where('status',1)->get();
                     $subcategory=DB::table('subcategoryinformation')->where('status',1)->get();
                     ?>

                     <?php if(isset($item)): ?>
                     <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemshow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                     <li>
                        <a href="<?php echo e(url('item/'.$itemshow->id)); ?>"><?php echo e($itemshow->item_name); ?> <i class="fa fa-angle-right" aria-hidden="true"></i></a>
                        <ul class="sub-category">

                           <?php if(isset($category)): ?>
                           <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryshow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php if($itemshow->id == $categoryshow->item_id): ?>

                           <li>
                              <a href="<?php echo e(url('category/'.$categoryshow->id)); ?>"><?php echo e($categoryshow->category_name); ?> <i class="fa fa-angle-right" aria-hidden="true"></i></a>

                              <ul class="multisub-category">

                                 <?php if(isset($subcategory)): ?>
                                 <?php $__currentLoopData = $subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategoryshow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <?php if($categoryshow->id == $subcategoryshow->category_id): ?>

                                 <li><a href="<?php echo e(url('subcategory/'.$subcategoryshow->id)); ?>"><?php echo e($subcategoryshow->subcategory_name); ?></a></li>

                                 <?php endif; ?>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 <?php endif; ?>

                              </ul>

                           </li>

                           <?php endif; ?>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <?php endif; ?>

                        </ul>
                     </li>

                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <?php endif; ?>

                  </ul>
               </div>
            </div>




            <div class="col-lg-9 col-12">
              <div class="menu-area">
                 <!-- Main Menu -->
                 <nav class="navbar navbar-expand-lg">
                    <div class="navbar-collapse">   
                       <div class="nav-inner"> 
                          <ul class="nav main-menu menu navbar-nav">
                             <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                             <li><a href="<?php echo e(url('allproduct')); ?>">All Product</a></li>
                             <li><a href="#">Offer Product's</a></li>
                             <li><a href="<?php echo e(url('allbrand')); ?>">Brand</a></li>
                             <li><a href="<?php echo e(url('aboutus')); ?>">About</a></li>
                             <li><a href="<?php echo e(url('contactus')); ?>">Contact Us</a></li>
                          </ul>
                       </div>
                    </div>
                 </nav>
                 <!--/ End Main Menu --> 
              </div>
           </div>
        </div>
     </div>
  </div>
</div>
<!--/ End Header Inner -->
</header>
<!--/ End Header -->






<?php echo $__env->yieldContent('content'); ?>









<!-- Start Footer Area -->
<footer class="footer">
  <!-- Footer Top -->
  <div class="footer-top section">
     <div class="container">
        <div class="row">
           <div class="col-lg-5 col-md-6 col-12">
              <!-- Single Widget -->
              <div class="single-footer about">
                 <div class="logo">
                    <a href="index.html"><img src="<?php echo e(url($setting->image)); ?>" alt="#"></a>
                 </div>
                 <p class="call">Got Question? Call us 24/7<span><a href="tel:+880 <?php echo e($setting->phone); ?>">+880 <?php echo e($setting->phone); ?></a></span></p>
                 <p>
                    <?php echo $contact->details; ?>

                 </p>
              </div>
              <!-- End Single Widget -->
           </div>
           <div class="col-lg-2 col-md-6 col-12">
            <!-- Single Widget -->
            <div class="single-footer links">
               <h4>Information</h4>
               <ul>
                  <li><a href="<?php echo e(url('aboutus')); ?>">About Us</a></li>
                  <li><a href="<?php echo e(url('FAQ')); ?>">Faq</a></li>
                  <li><a href="<?php echo e(url('termcondition')); ?>">Terms & Conditions</a></li>
               </div>
               <!-- End Single Widget -->
            </div>
            <div class="col-lg-2 col-md-6 col-12">
             <!-- Single Widget -->
             <div class="single-footer links">
                <h4>Customer Service</h4>
                <ul>
                   <li><a href="#">Payment Methods</a></li>
                   <li><a href="#">Returns</a></li>
                   <li><a href="<?php echo e(url('privacypolicy')); ?>">Privacy Policy</a></li>
                </ul>
             </div>
             <!-- End Single Widget -->
          </div>
          <div class="col-lg-3 col-md-6 col-12">
           <!-- Single Widget -->
           <div class="single-footer social">
              <h4>Find Us</h4>
              <!-- Single Widget -->
              <div class="mapouter">
                 <div class="gmap_canvas pt-3">

                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d861.1638893279683!2d90.36983283850287!3d23.836897305177263!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755c14a25d658d9%3A0x726505fe64ab3451!2sHOUSE-353%2C%205%20Avenue%205%2C%20Dhaka!5e0!3m2!1sen!2sbd!4v1648397778967!5m2!1sen!2sbd" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe><br>
                    <style>
                       .mapouter {
                          position: relative;
                          text-align: right;
                          height: 207px;
                          width: 227px;
                       }

                    </style><a href="https://www.embedgooglemap.net/">embed map on website</a>
                    <style>
                     .gmap_canvas {
                        overflow: hidden;
                        background: none !important;
                        height: 207px;
                        width: 227px;
                     }

                  </style>
               </div>
            </div>
            <!-- End Single Widget -->
            <ul>
             <li><a href="<?php echo e(url($setting->facebook)); ?>"><i class="ti-facebook"></i></a></li>
             <li><a href="<?php echo e(url($setting->twitter)); ?>"><i class="ti-twitter"></i></a></li>
             <li><a href="<?php echo e(url($setting->youtube)); ?>"><i class="ti-youtube"></i></a></li>
             <li><a href="<?php echo e(url($setting->instagram)); ?>"><i class="ti-instagram"></i></a></li>
          </ul>
       </div>
       <!-- End Single Widget -->
    </div>
 </div>
</div>
</div>
<!-- End Footer Top -->
<div class="copyright">
 <div class="container">
    <div class="inner">
       <div class="row">
          <div class="col-lg-6 col-12">
             <div class="left">
                <p>Copyright &copy; <script>document.write(new Date().getFullYear());</script>
                shoppingstore.com.bd All rights reserved</p>
             </div>
          </div>
          <div class="col-lg-6 col-12">
           <div class="right">
              <img src="<?php echo e(asset('public/frontend')); ?>/images/payments.png" alt="#">
           </div>
        </div>
     </div>
  </div>
</div>
</div>
</footer>
<!-- /End Footer Area -->




<div class="fixed-bottom bg-white p-2 d-md-none d-block text-center mobilefooter">
 <div class="row">
    <div class="col-md-5 col-5">
       <div class="row">
          <div class="col">
             <li><a href="" uk-toggle="target: #offcanvas-flip"><i class="fa fa-list-ul" aria-hidden="true"></i></a></li>
             <div class="mt-1 title">Menu</div>
          </div>
          <div class="col">
             <li><a href=""><i class="fa fa-bell"></i></a></li>
             <div class="mt-1 title">Review</div>
          </div>
       </div>
    </div>

    <div class="col-md-2 col-2 home">
     <a href="<?php echo e('/shoppingstore'); ?>"><i class="fa fa-home icons" aria-hidden="true"></i></a>
  </div>


  <div class="col-md-5 col-5">
     <div class="row">
        <div class="col">
           <li><a href="" uk-toggle="target: #offcanvas-none"><i class="fa fa-shopping-basket"></i></a></li>
           <div class="mt-1 title">Cart</div>
        </div>
        <div class="col">

         <?php if(Auth::check()): ?>
         <li><a href="<?php echo e(url('userdashboard')); ?>" ><i class="fa fa-user"></i></a></li>
         <div class="mt-1 title">Profile</div>
         <?php else: ?>
         <li><a href="<?php echo e(url('usersignin')); ?>" ><i class="fa fa-user"></i></a></li>
         <div class="mt-1 title">Login</div>
         <?php endif; ?>

      </div>
   </div>
</div>
</div>
</div>






<div id="offcanvas-none" uk-offcanvas="mode: slide; overlay:true; flip: true;" style="transition: 5s; z-index: 1100;">
 <div class="uk-offcanvas-bar cartbackground">
    <div class="card-header bg-white" style="border-bottom: 1px solid #ddd;">
       <div class="row">
          <div class="col-md-4 col-4">
             My Cart
          </div>
          <div class="col-md-4 col-4">
             <a href="<?php echo e(url('allclear')); ?>" class="float-right" style="color: red;">Cart Clear</a>
          </div>
          <div class="col-md-4 col-4">
             <span uk-icon="icon:close; ratio:1.2"
             class="uk-offcanvas-close icone float-right"></span>
          </div>
       </div>
    </div>

    <div class="card-body p-0" style="height:450px; overflow: hidden;">
     <div id="cartshow">

       <?php
       $Cart =Cart::content();
       ?>

       <?php if(isset($Cart)): ?>
       <?php $__currentLoopData = $Cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CartDataShow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

       <div class="col-md-12 pt-1 pb-1" style="border-bottom: 1px solid #ddd;">
         <div class="row">
           <div class="col-md-3 col-3">
              <center>
                <img src="<?php echo e(url($CartDataShow->options->image)); ?>" class="img-fluid">
             </center>
          </div>

          <div class="col-md-7 col-7">
           <span style="color: black;"><?php echo e($CartDataShow->name); ?></span>
           <br>

           <?php
           $Price = $CartDataShow->price;
           $Qty = $CartDataShow->qty;
           $Total = $Price * $Qty;
           ?>

           <span style="color: #00c431">৳ <?php echo e($CartDataShow->price); ?>.00 * <?php echo e($CartDataShow->qty); ?> = <?php echo e($Total); ?>.00 Tk.</span>
           <br>
        </div>

        <div class="col-md-2 col-2">
           <a href="<?php echo e(url('productremove/'.$CartDataShow->rowId)); ?>">
              <i class="fa fa-trash-o text-dark float-right"></i>
           </a>
        </div>

     </div>
  </div>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>

</div>
</div>

<!--------------End Body----------------->

<div class="col-sm-12 col-12 p-0" style="bottom: 0; position: absolute;">
  <div class="card-footer mt-3">
     <div class="row mt-2">
        <div class="col-md-6 col-6">
           Grand Total
        </div>

        <div class="col-md-6 col-6 text-right">
           ৳ <span id="cartamount"><?php echo e(Cart::subtotal()); ?></span>
        </div>
     </div>
     <br>

     <?php if(Auth::check()): ?>
     <a href="<?php echo e(url('checkout')); ?>" class="uk-button uk-button-secondary uk-width-1-1" style="background-color: #00c431; color: #fff;">Checkout</a>
     <?php else: ?>
     <a href="<?php echo e(url('usersignin')); ?>" class="uk-button uk-button-secondary uk-width-1-1" style="background-color: #00c431; color: #fff;">Checkout</a>
     <?php endif; ?>


  </div>
</div>
</div>
</div>

<!-----------End side Cart--------->


<!-- Jquery -->
<script src="<?php echo e(asset('public/frontend')); ?>/js/jquery.min.js"></script>
<script src="<?php echo e(asset('public/frontend')); ?>/js/jquery-migrate-3.0.0.js"></script>
<script src="<?php echo e(asset('public/frontend')); ?>/js/jquery-ui.min.js"></script>
<!-- Popper JS -->
<script src="<?php echo e(asset('public/frontend')); ?>/js/popper.min.js"></script>
<!-- Bootstrap JS -->
<script src="<?php echo e(asset('public/frontend')); ?>/js/bootstrap.min.js"></script>
<!-- Color JS -->
<script src="<?php echo e(asset('public/frontend')); ?>/js/colors.js"></script>
<!-- Slicknav JS -->
<script src="<?php echo e(asset('public/frontend')); ?>/js/slicknav.min.js"></script>
<!-- Owl Carousel JS -->
<script src="<?php echo e(asset('public/frontend')); ?>/js/owl-carousel.js"></script>
<!-- Magnific Popup JS -->
<script src="<?php echo e(asset('public/frontend')); ?>/js/magnific-popup.js"></script>
<!-- Waypoints JS -->
<script src="<?php echo e(asset('public/frontend')); ?>/js/waypoints.min.js"></script>
<!-- Countdown JS -->
<script src="<?php echo e(asset('public/frontend')); ?>/js/finalcountdown.min.js"></script>
<!-- Nice Select JS -->

<!-- Flex Slider JS -->
<script src="<?php echo e(asset('public/frontend')); ?>/js/flex-slider.js"></script>
<!-- ScrollUp JS -->
<script src="<?php echo e(asset('public/frontend')); ?>/js/scrollup.js"></script>
<!-- Onepage Nav JS -->
<script src="<?php echo e(asset('public/frontend')); ?>/js/onepage-nav.min.js"></script>
<!-- Easing JS -->
<script src="<?php echo e(asset('public/frontend')); ?>/js/easing.js"></script>
<!-- Active JS -->
<script src="<?php echo e(asset('public/frontend')); ?>/js/active.js"></script>
<script type="text/javascript" src="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js"></script>
<!-- UIkit JS -->
<script src="https://cdn.jsdelivr.net/npm/uikit@3.13.1/dist/js/uikit.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/uikit@3.13.1/dist/js/uikit-icons.min.js"></script>
<!-- Toastr JS -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

<script>
 <?php if(Session::has('messege')): ?>

 var type="<?php echo e(Session::get('alert-type', 'info')); ?>"

 switch(type){

    case 'info':
    toastr.options.positionClass = 'toast-top-right';
    toastr.info("<?php echo e(Session::get('messege')); ?>");

    break;

    case 'success':
    toastr.options.positionClass = 'toast-top-right';
    toastr.success("<?php echo e(Session::get('messege')); ?>");

    break;

    case 'warning':
    toastr.options.positionClass = 'toast-top-right';
    toastr.warning("<?php echo e(Session::get('messege')); ?>");

    break;

    case 'error':
    toastr.options.positionClass = 'toast-top-right';
    toastr.error("<?php echo e(Session::get('messege')); ?>");

    break;

 }

 <?php endif; ?>

</script>


<script>
 function categoryHideShow(){
    var box = document.querySelector(".main-category");
    box.classList.toggle("opacity");

 }
</script>

<script src="<?php echo e(asset('public/signin')); ?>/js/jquery.min.js"></script>
<script src="<?php echo e(asset('public/signin')); ?>/js/popper.js"></script>
<script src="<?php echo e(asset('public/signin')); ?>/js/bootstrap.min.js"></script>
<script src="<?php echo e(asset('public/signin')); ?>/js/main.js"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\shopping\resources\views/frontend/index.blade.php ENDPATH**/ ?>