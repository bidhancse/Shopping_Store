
<?php $__env->startSection('content'); ?>


<!-------------- Shop by Brands ------------->
<div class="col-sm-12 col-12 pb-5 pt-5" style=" background-color: #fff;">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-9 col-12 text-md-left text-center" >
				<span class="" style="font-family: Calibri; font-size: 30px; color: #000;"> Brands</span>
			</div>
			<div class="col-sm-3 col-12 text-md-right text-center subsearch mt-sm-0 mt-2">

				<form method="get" action="<?php echo e(url('searchbrand')); ?>">
					<?php echo csrf_field(); ?>
					<input type="hidden" name="_token">            
					<div class="input-group" style="width: 280px; margin-left: 47px;">
						<input type="text" class="form-control" id="searchbox" placeholder="Serach Brand" name="searchbrand"  autocomplete="off" required="" style="border-radius: 0px; box-shadow: none;">

						<div class="input-group-append">
							<button class="btn" type="submit" style="border-radius: 0px 5px 5px 0px; background: #333333; color: white; max-width: 10px; box-shadow: none;"><i class="fa fa-search" style="margin-left:-5px;"></i></button>
						</div>

					</div>
				</form>
			</div>
		</div>
	</div>


	<div class="container-fluid">
		<div class="col-sm-12 col-12">

			<div class="row" style="background:#fff; margin-top: 30px;">
				<?php if(isset($Allbrand)): ?>
				<?php $__currentLoopData = $Allbrand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $AllbrandShow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="p-2 col-lg-1 col-md-3 col-sm-4 col-4"
				style="background:#fff; border: 3px #f4f4f4  solid; align:center; ">

				<center style="padding:5px;">
					<a href="<?php echo e(url('brandproduct/'.$AllbrandShow->id)); ?>">

						<?php if(isset($AllbrandShow->image)): ?>
						<img src="<?php echo e(url($AllbrandShow->image)); ?>" class="img-responsive" alt=""
						style="max-height:40px;">
						<?php endif; ?>
					</a>
				</center>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</div>

		<div class="row">
			<div class="col-sm-12 col-12 mt-5" >
				<nav>
					<ul class="pagination"style="color: black;">
						<?php echo e($Allbrand->links()); ?>

					</ul>
				</nav>
			</div>
		</div>
	</div>
</div>
</div>
</div>

<!----------End Brands --------->



<?php $__env->stopSection(); ?>



<?php echo $__env->make('frontend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shoppingstore\resources\views/frontend/brand/brand.blade.php ENDPATH**/ ?>