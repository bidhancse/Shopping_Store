<div class="container">
     <div class="row justify-content-center">
         <div class="col-md-8">
             <div class="card">
                 <div class="card-header">Welcome!</div>
                   <div class="card-body">
                    <?php if(session('resent')): ?>
                         <div class="alert alert-success" role="alert">
                            <?php echo e(__('A fresh mail has been sent to your email address.')); ?>

                        </div>
                    <?php endif; ?>
                    <?php echo $content; ?>

                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\shop\resources\views/admin/customer/email-template.blade.php ENDPATH**/ ?>