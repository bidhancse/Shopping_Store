<?php
$setting = DB::table('settinginformation')->first();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  <meta name="description" content="">
  <meta name="author" content="MHS">
  <!--favicon icon-->
  <link rel="icon" type="image/png" href="<?php echo e(url($setting->favicon)); ?>">
  <title><?php echo e($setting->title); ?></title>
  <!--google font-->
  <link href="http://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">
  <!--common style-->
  <link href="<?php echo e(asset('public/backend')); ?>/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo e(asset('public/backend')); ?>/assets/vendor/lobicard/css/lobicard.css" rel="stylesheet">
  <link href="<?php echo e(asset('public/backend')); ?>/assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
  <link href="<?php echo e(asset('public/backend')); ?>/assets/vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet">
  <link href="<?php echo e(asset('public/backend')); ?>/assets/vendor/themify-icons/css/themify-icons.css" rel="stylesheet">
  <!--bs4 data table-->
  <link href="<?php echo e(asset('public/backend')); ?>/assets/vendor/data-tables/dataTables.bootstrap4.min.css" rel="stylesheet">
  <!--summernote-->
  <link href="<?php echo e(asset('public/backend')); ?>/assets/vendor/summernote/summernote-bs4.css" rel="stylesheet">
  <!--select2-->
  <link href="<?php echo e(asset('public/backend')); ?>/assets/vendor/select2/css/select2.css" rel="stylesheet">

  <!--custom css-->
  <link href="<?php echo e(asset('public/backend')); ?>/assets/css/main.css" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('public/backend')); ?>/assets/css/toast.css">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.6.2/css/buttons.dataTables.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

</head>
<body class="app header-fixed left-sidebar-fixed right-sidebar-fixed right-sidebar-overlay right-sidebar-hidden" onload="startTime()" onload="startTime()">


  

  <style>
/* width */
::-webkit-scrollbar {
  width: 4px;
}

/* Track */
::-webkit-scrollbar-track {
  background: #ddd; 
}

/* Handle */
::-webkit-scrollbar-thumb {
  background: #fd8900; 
}

/* Handle on hover */
::-webkit-scrollbar-thumb:hover {
  background: #fd8900; 
}


/*......data table image hover.....*/

* {
  box-sizing: border-box;
}

.zoom:hover {
  -ms-transform: scale(1.5); /* IE 9 */
  -webkit-transform: scale(1.5); /* Safari 3-8 */
  transform: scale(1.5); 
}


</style>





<!--===========header start===========-->
<header class="app-header navbar">

  <!--brand start-->
  <div class="navbar-brand">
    <a class="" href="<?php echo e(url('/admin')); ?>">
      <strong style="font-size: 22px;">
        <span style="color: red; font-family: Franklin Gothic Medium;">Admin</span> 
        <span style="color: black; font-family: Franklin Gothic Medium;">Panel</span>
      </strong>
    </a>
  </div>
  <!--brand end-->

  <!--left side nav toggle start-->
  <ul class="nav navbar-nav mr-auto">
    <li class="nav-item d-lg-none">
      <button class="navbar-toggler mobile-leftside-toggler" type="button"><i class="ti-align-right"></i></button>
    </li>
    <li class="nav-item d-md-down-none">
      <a class="nav-link navbar-toggler left-sidebar-toggler" href="#"><i class=" ti-align-right"></i></a>
    </li>
  </ul>
  <!--left side nav toggle end-->

  <!--right side nav start-->
  <ul class="nav navbar-nav ml-auto">


    <li class="nav-item dropdown dropdown-slide" style="margin-right: 10px;">
      <a class="nav-link nav-pill user-avatar" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
        <img src="<?php echo e(asset('public/backend')); ?>/assets/img/user.png" alt="John Doe">
      </a>
      <div class="dropdown-menu dropdown-menu-right dropdown-menu-accout">
        <div class="dropdown-header pb-3">
          <div class="media d-user">
            <img class="align-self-center mr-3" src="<?php echo e(asset('public/backend')); ?>/assets/img/user.png" alt="John Doe">
            <div class="media-body">
              <h5 class="mt-0 mb-0"><?php echo e(Auth()->user()->name); ?></h5>
              <span><?php echo e(Auth()->user()->email); ?></span>
            </div>
          </div>
        </div>

        <a class="dropdown-item" href="#"><i class=" ti-reload"></i> Activity</a>
        <a class="dropdown-item" href="#"><i class=" ti-email"></i> Message</a>
        <a class="dropdown-item" href="#"><i class=" ti-user"></i> Profile</a>
        <a class="dropdown-item" href="#"><i class=" ti-layers-alt"></i> Projects <span class="badge badge-primary">4</span> </a>

        <div class="dropdown-divider"></div>

        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
        document.getElementById('logout-form').submit();">
        <i class=" ti-lock"></i> <?php echo e(__('Logout')); ?></a>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
          <?php echo csrf_field(); ?>
        </form>
      </div>
    </li>
  </ul>

  <!--right side nav end-->
</header>
<!--===========header end===========-->

<!--===========app body start===========-->
<div class="app-body">

  <!--left sidebar start-->
  <div class="left-sidebar">
    <nav class="sidebar-menu">
      <ul id="nav-accordion">
        <li class="nav-title">
          <h5 class="text-uppercase">DEVELOPER</h5>
        </li>
        <li class="sub-menu">
          <a href="javascript:;">
            <i class=" ti-home"></i>
            <span>Developer Tools</span>
          </a>
          <ul class="sub">
            <li><a  href="<?php echo e(url('mainmenu')); ?>">Main Menu</a></li>
            <li><a  href="<?php echo e(url('submenu')); ?>">Sub Menu</a></li>
          </ul>
        </li>

        <li class="nav-title">
          <h5 class="text-uppercase">Components</h5>
        </li>

        <li class="sub-menu">
          <a href="javascript:;" class="<?php if(request()->path() === 'createadmin' || request()->path() === 'manageadmin'): ?><?php echo e('active'); ?><?php else: ?> <?php endif; ?>">
            <i class="fa fa-folder-open"></i>
            <span>Admin Setup</span>
          </a>
          <ul class="sub">
            <li>
              <a href="<?php echo e(url('createadmin')); ?>" class="<?php if(request()->path() === 'createadmin'): ?><?php echo e('text-warning'); ?><?php else: ?> <?php endif; ?>">Create Admin</a>
            </li>
            <li>
              <a href="<?php echo e(url('manageadmin')); ?>" class="<?php if(request()->path() === 'manageadmin'): ?><?php echo e('text-warning'); ?><?php else: ?> <?php endif; ?>">Manage Admin</a>
            </li>
          </ul>

          <li class="sub-menu">
            <a href="javascript:;" class="<?php if(request()->path() === 'item' || request()->path() === 'manageitem'): ?><?php echo e('active'); ?><?php else: ?> <?php endif; ?>">
              <i class="fa fa-folder-open"></i>
              <span>Item Information</span>
            </a>
            <ul class="sub">
              <li>
                <a href="<?php echo e(url('item')); ?>" class="<?php if(request()->path() === 'item'): ?><?php echo e('text-warning'); ?><?php else: ?> <?php endif; ?>">Item Information</a>
              </li>
              <li>
                <a href="<?php echo e(url('manageitem')); ?>" class="<?php if(request()->path() === 'manageitem'): ?><?php echo e('text-warning'); ?><?php else: ?> <?php endif; ?>">Manage Item</a>
              </li>

            </li>     
          </ul>

          <li class="sub-menu">
            <a href="javascript:;" class="<?php if(request()->path() === 'category' || request()->path() === 'managecategory' || request()->path() === 'subcategory' || request()->path() === 'managesubcategory'): ?><?php echo e('active'); ?><?php else: ?> <?php endif; ?>">
              <i class="fa fa-folder-open"></i>
              <span>Category Information</span>
            </a>
            <ul class="sub">
              <li>
                <a href="<?php echo e(url('category')); ?>" class="<?php if(request()->path() === 'category'): ?><?php echo e('text-warning'); ?><?php else: ?> <?php endif; ?>">Category Add</a>
              </li>
              <li>
                <a href="<?php echo e(url('managecategory')); ?>" class="<?php if(request()->path() === 'managecategory'): ?><?php echo e('text-warning'); ?><?php else: ?> <?php endif; ?>">Manage Category</a>
              </li>
              <li>
                <a href="<?php echo e(url('subcategory')); ?>" class="<?php if(request()->path() === 'subcategory'): ?><?php echo e('text-warning'); ?><?php else: ?> <?php endif; ?>">Sub Category</a>
              </li>
              <li>
                <a href="<?php echo e(url('managesubcategory')); ?>" class="<?php if(request()->path() === 'managesubcategory'): ?><?php echo e('text-warning'); ?><?php else: ?> <?php endif; ?>">Manage Sub Category</a>
              </li>
            </ul>

            <li class="sub-menu">
              <a href="javascript:;" class="<?php if(request()->path() === 'brand' || request()->path() === 'managebrand'): ?><?php echo e('active'); ?><?php else: ?> <?php endif; ?>">
                <i class="fa fa-folder-open"></i>
                <span>Brand Information</span>
              </a>
              <ul class="sub">
                <li>
                  <a href="<?php echo e(url('brand')); ?>" class="<?php if(request()->path() === 'brand'): ?><?php echo e('text-info'); ?><?php else: ?> <?php endif; ?>">Brand Add</a>

                </li>
                <li>
                  <a href="<?php echo e(url('managebrand')); ?>" class="<?php if(request()->path() === 'managebrand'): ?><?php echo e('text-info'); ?><?php else: ?> <?php endif; ?>">Manage Brand</a>

                </li>
              </ul>
            </li>

            <li class="sub-menu">
              <a href="javascript:;" class="<?php if(request()->path() === 'product' || request()->path() === 'manageproduct'): ?><?php echo e('active'); ?><?php else: ?> <?php endif; ?>">
                <i class="fa fa-folder-open"></i>
                <span>Product Information</span>
              </a>
              <ul class="sub">
                <li>
                  <a href="<?php echo e(url('product')); ?>" class="<?php if(request()->path() === 'product'): ?><?php echo e('text-info'); ?><?php else: ?> <?php endif; ?>">Product Add</a>
                </li>
                <li>
                  <a href="<?php echo e(url('manageproduct')); ?>" class="<?php if(request()->path() === 'manageproduct'): ?><?php echo e('text-info'); ?><?php else: ?> <?php endif; ?>">Manage Product</a>
                </li>
                <li>
                  <a href="<?php echo e(url('viewallproduct')); ?>" class="<?php if(request()->path() === 'viewallproduct'): ?><?php echo e('text-info'); ?><?php else: ?> <?php endif; ?>" target="_blank">View All Product</a>
                </li>
              </ul>
            </li>

            <li class="sub-menu">
              <a  href="javascript:;" class="<?php if(request()->path() === 'orderinfomation' || request()->path() === 'pendingorder' || request()->path() === 'processingorder' || request()->path() === 'shippingorder' || request()->path() === 'completdorder' || request()->path() === 'monthlyorderreport'): ?><?php echo e('active'); ?><?php else: ?> <?php endif; ?>">
                <i class="fa fa-folder-open"></i>
                <span>Order Infomation</span>
              </a>
              <ul class="sub">
                <li>
                  <a href="<?php echo e(url('orderinfomation')); ?>" class="<?php if(request()->path() === 'orderinfomation'): ?><?php echo e('text-info'); ?><?php else: ?> <?php endif; ?>">All Order Infomation</a>
                </li>
                <li>
                  <a href="<?php echo e(url('pendingorder')); ?>" class="<?php if(request()->path() === 'pendingorder'): ?><?php echo e('text-info'); ?><?php else: ?> <?php endif; ?>">Pending Order</a>
                </li>
                <li>
                  <a href="<?php echo e(url('processingorder')); ?>" class="<?php if(request()->path() === 'processingorder'): ?><?php echo e('text-info'); ?><?php else: ?> <?php endif; ?>">Processing Order</a>
                </li>
                <li>
                  <a href="<?php echo e(url('shippingorder')); ?>" class="<?php if(request()->path() === 'shippingorder'): ?><?php echo e('text-info'); ?><?php else: ?> <?php endif; ?>">Shipping Order</a>
                </li>
                <li>
                  <a href="<?php echo e(url('completdorder')); ?>" class="<?php if(request()->path() === 'completdorder'): ?><?php echo e('text-info'); ?><?php else: ?> <?php endif; ?>">Completd Order</a>
                </li>
                <li>
                  <a href="<?php echo e(url('monthlyorderreport')); ?>" class="<?php if(request()->path() === 'monthlyorderreport'): ?><?php echo e('text-info'); ?><?php else: ?> <?php endif; ?>">Monthly Order Report</a>
                </li>
              </ul>
            </li>

            <li class="sub-menu">
              <a href="javascript:;" class="<?php if(request()->path() === 'slider' || request()->path() === 'manageslider' || request()->path() === 'setting' || request()->path() === 'about' || request()->path() === 'contact' || request()->path() === 'privacy&policy' || request()->path() === 'term&condition' || request()->path() === 'howtobuy' || request()->path() === 'faq' || request()->path() === 'managefaq'): ?><?php echo e('active'); ?><?php else: ?> <?php endif; ?>">
                <i class="fa fa-folder-open"></i>
                <span>Website Setting</span>
              </a>
              <ul class="sub">
                <li>
                  <a href="<?php echo e(url('slider')); ?>" class="<?php if(request()->path() === 'slider'): ?><?php echo e('text-info'); ?><?php else: ?> <?php endif; ?>">Slider</a>
                </li>
                <li>
                  <a href="<?php echo e(url('manageslider')); ?>" class="<?php if(request()->path() === 'manageslider'): ?><?php echo e('text-info'); ?><?php else: ?> <?php endif; ?>">Manage Slider</a>
                </li>
                <li>
                  <a href="<?php echo e(url('setting')); ?>" class="<?php if(request()->path() === 'setting'): ?><?php echo e('text-info'); ?><?php else: ?> <?php endif; ?>">Setting</a>
                </li>
                <li>
                  <a href="<?php echo e(url('about')); ?>" class="<?php if(request()->path() === 'about'): ?><?php echo e('text-info'); ?><?php else: ?> <?php endif; ?>">About</a>
                </li>
                <li>
                  <a href="<?php echo e(url('contact')); ?>" class="<?php if(request()->path() === 'contact'): ?><?php echo e('text-info'); ?><?php else: ?> <?php endif; ?>">Contact</a>
                </li>
                <li>
                  <a href="<?php echo e(url('privacy&policy')); ?>" class="<?php if(request()->path() === 'privacy&policy'): ?><?php echo e('text-info'); ?><?php else: ?> <?php endif; ?>">Privacy & Policy</a>
                </li>
                <li>
                  <a href="<?php echo e(url('term&condition')); ?>" class="<?php if(request()->path() === 'term&condition'): ?><?php echo e('text-info'); ?><?php else: ?> <?php endif; ?>">Term & Condition</a>
                </li>
                <li>
                  <a href="<?php echo e(url('howtobuy')); ?>" class="<?php if(request()->path() === 'howtobuy'): ?><?php echo e('text-info'); ?><?php else: ?> <?php endif; ?>">How To Buy</a>
                </li>
                <li>
                  <a href="<?php echo e(url('faq')); ?>" class="<?php if(request()->path() === 'faq'): ?><?php echo e('text-info'); ?><?php else: ?> <?php endif; ?>">FAQ</a>
                </li>
                <li>
                  <a href="<?php echo e(url('managefaq')); ?>" class="<?php if(request()->path() === 'managefaq'): ?><?php echo e('text-info'); ?><?php else: ?> <?php endif; ?>">Manage FAQ</a>
                </li>
              </ul>
            </li>

            <li class="sub-menu">
              <a href="javascript:;" class="<?php if(request()->path() === 'customermessage'): ?><?php echo e('active'); ?><?php else: ?> <?php endif; ?>">
                <i class="fa fa-folder-open"></i>
                <span>Customer Message</span>
              </a>
              <ul class="sub">
                <li>
                  <a href="<?php echo e(url('customermessage')); ?>" class="<?php if(request()->path() === 'customermessage'): ?><?php echo e('text-info'); ?><?php else: ?> <?php endif; ?>">Customer Message</a>
                </li>
              </ul>
            </li>        

          </li>
        </nav>
      </div>


      <?php echo $__env->yieldContent('content'); ?>


      <!--left sidebar end-->
    </div>
    <!--===========footer start===========-->
    <footer class="app-footer">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-4 text-right">
           <span id="clock"></span>
           <span id="date"> /  <?php echo e(date('l, F j, Y')); ?></span>
         </div>

         <div class="col-lg-4 text-right">

         </div>

         <div class="col-lg-4 text-right">

          <span>
           <?php echo date("Y"); ?> © Copyright Develop By <a href="https://www.facebook.com/Bidhan716/">Bidhan Nath</a>
         </span>
       </div>

     </div>
   </div>
 </footer>
 <!--===========footer end===========-->

 <!-- Placed js at the end of the page so the pages load faster -->
 <script src="<?php echo e(asset('public/backend')); ?>/assets/vendor/jquery/jquery.min.js"></script>
 <script src="<?php echo e(asset('public/backend')); ?>/assets/vendor/jquery-ui-1.12.1/jquery-ui.min.js"></script>
 <script src="<?php echo e(asset('public/backend')); ?>/assets/vendor/popper.min.js"></script>
 <script src="<?php echo e(asset('public/backend')); ?>/assets/vendor/bootstrap/js/bootstrap.min.js"></script>
 <script src="<?php echo e(asset('public/backend')); ?>/assets/vendor/jquery-ui-touch/jquery.ui.touch-punch-improved.js"></script>
 <script class="include" type="text/javascript" src="<?php echo e(asset('public/backend')); ?>/assets/vendor/jquery.dcjqaccordion.2.7.js"></script>
 <script src="<?php echo e(asset('public/backend')); ?>/assets/vendor/lobicard/js/lobicard.js"></script>
 <script src="<?php echo e(asset('public/backend')); ?>/assets/vendor/jquery.scrollTo.min.js"></script>

 <!--datatables-->
 <script src="<?php echo e(asset('public/backend')); ?>/assets/vendor/data-tables/jquery.dataTables.min.js"></script>
 <script src="<?php echo e(asset('public/backend')); ?>/assets/vendor/data-tables/dataTables.bootstrap4.min.js"></script>

 <!--toastr-->
 <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

 <script>
  $(document).ready(function() {
    $('#bs4-table').DataTable();
  } );
</script>


<script>
  <?php if(Session::has('messege')): ?>

  var type="<?php echo e(Session::get('alert-type', 'info')); ?>"

  switch(type){

    case 'info':
    toastr.options.positionClass = 'toast-top-right';
    toastr.info("<?php echo e(Session::get('messege')); ?>");

    break;

    case 'success':
    toastr.options.positionClass = 'toast-top-right';
    toastr.success("<?php echo e(Session::get('messege')); ?>");

    break;

    case 'warning':
    toastr.options.positionClass = 'toast-top-right';
    toastr.warning("<?php echo e(Session::get('messege')); ?>");

    break;

    case 'error':
    toastr.options.positionClass = 'toast-top-right';
    toastr.error("<?php echo e(Session::get('messege')); ?>");

    break;

  }

  <?php endif; ?>

</script>

<!--vectormap-->
<script src="<?php echo e(asset('public/backend')); ?>/assets/js/scripts.js"></script>

<!--summernote-->
<script src="<?php echo e(asset('public/backend')); ?>/assets/vendor/summernote/summernote-bs4.min.js"></script>
<script>
  $(document).ready(function() {
    $('#summernote').summernote({
                height: 100,                 // set editor height
                minHeight: null,             // set minimum height of editor
                maxHeight: null,             // set maximum height of editor
                focus: true                  // set focus to editable area after initializing summernote
              });
  });
</script>

<script src="<?php echo e(asset('public/backend')); ?>/assets/vendor/summernote/summernote-bs4.min.js"></script>
<script>
  $(document).ready(function() {
    $('#summernotes').summernote({
                height: 100,                 // set editor height
                minHeight: null,             // set minimum height of editor
                maxHeight: null,             // set maximum height of editor
                focus: true                  // set focus to editable area after initializing summernote
              });
  });
</script>

<script>
  $(document).ready(function() {
    $('#summernoteabout').summernote({
                height: 300,                 // set editor height
                minHeight: null,             // set minimum height of editor
                maxHeight: null,             // set maximum height of editor
                focus: true                  // set focus to editable area after initializing summernote
              });
  });
</script>

<!--select2-->
<script src="<?php echo e(asset('public/backend')); ?>/assets/vendor/select2/js/select2.min.js"></script>
<script src="<?php echo e(asset('public/backend')); ?>/assets/vendor/select2-init.js"></script>

<script>
 /* Navbar ClockDate */
 function startTime() {
  var today = new Date();
  var hr = today.getHours();
  var min = today.getMinutes();
  var sec = today.getSeconds();
  ap = (hr < 12) ? "<span>AM</span>" : "<span>PM</span>";
  hr = (hr == 0) ? 12 : hr;
  hr = (hr > 12) ? hr - 12 : hr;
    //Add a zero in front of numbers<10
    hr = checkTime(hr);
    min = checkTime(min);
    sec = checkTime(sec);
    document.getElementById("clock").innerHTML = hr + ":" + min + ":" + sec + " " + ap;
    
    var time = setTimeout(function(){ startTime() }, 500);
  }
  function checkTime(i) {
    if (i < 10) {
     i = "0" + i;
   }
   return i;
 }
</script>

<script>
  imgInp.onchange = evt => {
    const [file] = imgInp.files
    if (file) {
      blah.src = URL.createObjectURL(file)
    }
  }
</script>

<script>
  $(document).ready(function() {
    $('#table').DataTable();
  } );
</script>

<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/dataTables.buttons.min.js
"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js
"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.colVis.min.js"></script>
"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.7.1/js/buttons.html5.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.flash.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    $('#example').DataTable( {
     responsive: true,
     "order": [[ 0, "desc" ]],
     "lengthMenu": [[10, 5, 15, 25, 50, -1], [10,5,15, 25, 50, "All"]],
     dom: 'Bfrtip',
     buttons: [
     {
      extend: 'copyHtml5',
      exportOptions: {
        columns: [ 0, ':visible' ]
      }
    },
    {
      extend: 'excelHtml5',
      exportOptions: {
        columns: ':visible'
      }
    },
    {
      extend: 'pdf',
      exportOptions: {
        columns: ':visible'
      }
    },
    {
      extend: 'print',
      exportOptions: {
       columns: ':visible'
     }
   },
   'colvis','pageLength'
   ]
 } );
  } );
</script>

</body>

</html>

<?php /**PATH C:\xampp\htdocs\shoppingstore\resources\views/admin/index.blade.php ENDPATH**/ ?>